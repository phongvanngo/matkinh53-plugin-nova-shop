let URL_ADMIN_AJAX;
let categories_information;
