<?php

function BuildProductSinglePage() {
    echo 'hello';
}