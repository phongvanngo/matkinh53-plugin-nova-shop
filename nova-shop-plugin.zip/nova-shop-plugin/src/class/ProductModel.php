<?php

namespace NovaShop;

class ProductModel
{
    public $title;
    public $url;
    public $images;
    public $regular_price;
    public $official_price;
    public $is_sale;
}